<?php
session_start();
include "../koneksi.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>LOGIN</title>
<link rel="stylesheet" href="bootstrap.min.css">
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
<body>
<?php
$proses=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_GET['proses'])));
if($proses=="login"){
    $username=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['username'])));
    $password=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['password'])));
    $cekakun=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM admin WHERE username='$username' AND password='$password'"));
    if($cekakun!=0){
        $_SESSION['username']=$username;
        $_SESSION['password']=$password;
        header("Location: index.php");
        echo "<h3>Sukses!! Login Berhasil</h3>";
    }else{
        echo "<h3>Maaf!! Anda Gagal Login, Silahkan Coba Kembali</h3>";
    }
    
}
?>
<style>
        body{
            background-image: url(bg1.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            background-attachment: fixed;
            height: 100%;
        }
        .title{
            text-align: center;
            font-size: 2.5em;
            color: #000;
        }
 </style>
<div class="container">
    <center><h1 style="font-family: serif; padding-bottom: 60px; padding-top: 20px"></h1></center>
        <form method="post" action="?proses=login">
            <center><h2 style="font-family: serif;">LOGIN ADMIN</h2></center>
                <div class="container">
                    <div class="col-50">
                        <div class="form-group">
                            <label class="control-label col-sm-2">Username </label>
                                <div class="col-sm-12">
                                    <input type="text" name="username" placeholder="Masukkan Username">
                                </div>
                                <label class="control-label col-sm-2" >Password</label>
                                    <div class="col-sm-12">
                                        <input type="password" name="password" placeholder="Masukkan Kata Sandi">
                                    </div>
                                    <div class="col-sm-offset-2 col-sm-12">
                                        <div class="col-sm-12">
                                            <button type="submit">Login Admin</button>
                                        </div>
                                    </div>
                    </div>
                </div>
        </form>
</div>
</body>
</html>