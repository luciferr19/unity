<h3>Edit Produk</h3>
<?php
$idproduk=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_GET['idproduk'])));
$proses=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_GET['proses'])));
if($proses=="update"){
	$idkategoriproduk=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['idkategoriproduk'])));
	$nama_produk=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['nama_produk'])));
	$stok=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['stok'])));
	$harga=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['harga'])));
	$deskripsi_singkat=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['deskripsi_singkat'])));
	$deskripsi=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['deskripsi'])));

	$nama_gambar=@$_FILES['gambar']['name'];
	$tmp_gambar=@$_FILES['gambar']['tmp_name'];
	if(!empty($nama_gambar)){
		$cekgambar=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM produk WHERE idproduk='$idproduk'"));
		if(!empty($cekgambar['gambar'])){ //gambar akan dihapus jika didatabase sebelumnya sudah ada gambar
			unlink("../images/$cekgambar[gambar]");
		}
		copy($tmp_gambar, "../images/$nama_gambar");
		$update_gambar=mysqli_query($koneksi,"UPDATE produk SET gambar='$nama_gambar' WHERE idproduk='$idproduk'");

	}

	$update=mysqli_query($koneksi,"UPDATE produk SET idkategoriproduk='$idkategoriproduk', nama_produk='$nama_produk', stok='$stok', harga='$harga', deskripsi_singkat='$deskripsi_singkat', deskripsi='$deskripsi' WHERE idproduk='$idproduk'");
	if($update){
		echo "Sukses!! Update Data Berhasil";
		//header("Location: ?page=manajemen_produk");
	}else{
		echo "Maaf!! Proses Update Data Gagal";
	}
}


$tampildata=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM produk WHERE idproduk='$idproduk'"));
?>
<form method="post" action="?page=manajemen_produk_edit&&proses=update&&idproduk=<?php echo $idproduk; ?>" enctype="multipart/form-data">
	<div class="row">
        <label class="col-4">Kategori Produk</label>
        <div class="col-8">
            <select name="idkategoriproduk">
                <?php
                    $katprod=mysqli_query($koneksi,"SELECT * FROM kategori_produk");
                    while($katprod1=mysqli_fetch_array($katprod)){
                ?>
                <option value="<?php echo $katprod1['idkategoriproduk'] ?>" <?php if($tampildata['idkategoriproduk']==$katprod1['idkategoriproduk']){ ?>selected <?php } ?>><?php echo $katprod1['kategori'] ?></option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Nama Produk</label>
        <div class="col-8">
        	<input type="text" name="nama_produk" value="<?php echo $tampildata['nama_produk']; ?>">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Stok Produk</label>
        <div class="col-8">
        	<input type="text" name="stok" value="<?php echo $tampildata['stok']; ?>">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">harga</label>
        <div class="col-8">
        	<input type="number" name="harga" value="<?php echo $tampildata['harga']; ?>">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Deskripsi Singkat</label>
        <div class="col-8">
        	<input type="text" name="deskripsi_singkat"  value="<?php echo $tampildata['deskripsi_singkat']; ?>">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Deskripsi Lengkap</label>
        <div class="col-8">
        	<textarea name="deskripsi" rows="10" style="width:100%;"><?php echo $tampildata['deskripsi']; ?></textarea>
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Upload Foto Produk</label>
        <div class="col-8">
        	<img src="../images/<?php echo $tampildata['gambar']; ?>" width="100"><br>

        	<input type="file" name="gambar">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">&nbsp;</label>
        <div class="col-8">
        	<button type="submit">Simpan Data</button>
        </div>
    </div>
</form>