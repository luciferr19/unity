<?php
$cekuserlogin=$_SESSION['username'];
?>
<?php
if(empty($cekuserlogin)){
header("Location: login.php");
} else{ ?>

<h3>Tambah Barang</h3>
<?php
//proses simpan data
$proses=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_GET['proses'])));
if($proses=="simpan"){
	$idkategoriproduk=$_POST['idkategoriproduk'];
	$nama_produk=$_POST['nama_produk'];
	$stok=$_POST['stok'];
	$harga=$_POST['harga'];
	$deskripsi_singkat=$_POST['deskripsi_singkat'];
	$deskripsi=$_POST['deskripsi'];
	$tanggal_input=date("Y-m-d");
	$waktu_input=date("H:i:s");
	
	$nama_gambar=@$_FILES['gambar']['name'];
	$tmp_gambar=@$_FILES['gambar']['tmp_name'];
	if(!empty($nama_gambar)){
		copy($tmp_gambar, "../images/$nama_gambar");
	}
	$simpan=mysqli_query($koneksi,"INSERT INTO produk(idkategoriproduk,nama_produk,stok,harga,deskripsi_singkat,deskripsi,tanggal_input,waktu_input,gambar) VALUES('$idkategoriproduk','$nama_produk','$stok','$harga','$deskripsi_singkat','$deskripsi','$tanggal_input','$waktu_input','images/$nama_gambar')");
	if($simpan){
		echo "<h3>Input Data Berhasil</h3>";
	}else{
		echo "<h3>Input Data Gagal</h3>";
	}
}
// Ini baris Hapus Data
if($proses=="hapus"){
	$idproduk=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_GET['idproduk'])));
	$cekdata=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM produk WHERE idproduk='$idproduk'"));
	unlink("../$cekdata[gambar]");
	
	$hapus=mysqli_query($koneksi,"DELETE FROM produk WHERE idproduk='$idproduk'");
	if($hapus){
		echo "<h3>Hapus Data Berhasil</h3>";
	}else{
		echo "<h3>Hapus Data Gagal</h3>";
	}
}
?>

<form method="post" action="?page=manajemen_produk&&proses=simpan" enctype="multipart/form-data">
	<div class="row">
        <label class="col-4">Kategori Produk</label>
        <div class="col-8">
            <select name="idkategoriproduk">
                <?php
                    $katprod=mysqli_query($koneksi,"SELECT * FROM kategori_produk");
                    while($katprod1=mysqli_fetch_array($katprod)){
                ?>
                <option value="<?php echo $katprod1['idkategoriproduk'] ?>"><?php echo $katprod1['kategori'] ?></option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Nama Produk</label>
        <div class="col-8">
        	<input type="text" name="nama_produk">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Stok Produk</label>
        <div class="col-8">
        	<input type="text" name="stok">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">harga</label>
        <div class="col-8">
        	<input type="number" name="harga">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Deskripsi Singkat</label>
        <div class="col-8">
        	<input type="text" name="deskripsi_singkat">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Deskripsi Lengkap</label>
        <div class="col-8">
        	<textarea name="deskripsi" rows="10" style="width:100%;"></textarea>
        </div>
    </div>
    <div class="row">
    	<label class="col-4">Upload Foto Produk</label>
        <div class="col-8">
        	<input type="file" name="gambar">
        </div>
    </div>
    <div class="row">
    	<label class="col-4">&nbsp;</label>
        <div class="col-8">
        	<button type="submit">Simpan Data</button>
        </div>
    </div>
</form>

<h3>Tampil Data</h3>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
	<tr>
    	<td>No</td>
        <td>Nama Produk</td>
        <td>Harga</td>
        <td>&nbsp;</td>
    </tr>
    <?php
	$i=1;
	$tampil=mysqli_query($koneksi,"SELECT * FROM produk");
	while($cetak=mysqli_fetch_array($tampil)){
	?>
    <tr>
    	<td><?php echo $i; ?></td>
        <td><?php echo $cetak['nama_produk']; ?></td>
        <td><?php echo $cetak['harga']; ?></td>
        <td>
        	<a href="?page=manajemen_produk_edit&&idproduk=<?php echo $cetak['idproduk']; ?>">Edit</a>
            <a href="?page=manajemen_produk&&idproduk=<?php echo $cetak['idproduk']; ?>&&proses=hapus">Hapus</a>
        </td>
    </tr>
    <?php  $i=$i+1; } ?>
</table>

<?php } ?>