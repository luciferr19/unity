<?php
error_reporting (E_ALL ^ E_NOTICE);
$cekuserlogin=$_SESSION['username'];
?>
<?php
if(empty($cekuserlogin)){
header("Location: login.php");
} else{ ?>

<h3>MANAJAMEN AKUN</h3>

<?php
	$proses=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_GET['proses'])));
	if($proses=="simpan"){
		$nama=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['nama'])));
		$username=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['username'])));
		$password=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['password'])));
		$simpan=mysqli_query($koneksi,"INSERT INTO admin(nama,username,password) VALUES('$nama','$username','$password')");
		if($simpan){ echo "Simpan Akun Berhasil"; }else{ echo "Simpan Akun Gagal"; }
	}
?>

<form method="post" action="?page=manajemen_akun&&proses=simpan">
	<div class="row">
		<label class="col-4">Nama Anda</label>
		<div class="col-8">
			<input type="text" name="nama" placeholder="Silahkan Masukkan Nama Akun">
		</div>
	</div>
	<div class="row">
		<label class="col-4">Username</label>
		<div class="col-8">
			<input type="text" name="username" placeholder="Silahkan Masukkan Username Anda">
		</div>
	</div>
	<div class="row">
		<label class="col-4">Password</label>
		<div class="col-8">
			<input type="password" name="password" placeholder="Silahkan Masukkan Password anda">
		</div>
	</div>
	<div class="row">
		<label class="col-4">&nbsp;</label>
		<div class="col-8">
			<input type="submit" name="Submit" value="Simpan Data">
		</div>
	</div>
</form>


<?php } ?>