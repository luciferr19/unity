<!DOCTYPE html>
<?php
include "koneksi.php";

    
    if (isset($_POST['daftar']))
    {
        $k = $_POST['password'];
        $k1 = $_POST['password1'];
        if($k === $k1){
           $user = $_POST['username'];
        $pass = $_POST['password'];
        $query = mysqli_query($connect, "INSERT INTO login (username,password) VALUES ('$user','$pass')");
            header("Location: login.php");
         
        }
        else{

            ?><script>
            alert ("Konfirmasi password tidak tepat");</script><?php
        }
        
    }
?>
<html>
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Daftar | REENREN</title>
        <!--Menyisipkan Bootstrap-->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
    <style>
        body{
            background-image: url(bg1.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            background-attachment: fixed;
            height: 100%;
        }
        .title{
            text-align: center;
            font-size: 2.5em;
            color: #000;
        }
 
         
    </style>
       
        <div class="container">
            <form method='post' action='daftar.php' class="form-login"><center><h2 style="font-family: serif;">DAFTAR</h2></center>
                <div class="container">
                    <div class="col-12">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="user">Username</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" id="user" placeholder="Masukkan Username" name="username" required>
                            </div>
                            <label class="control-label col-sm-2" for="password">Password</label>
                            <div class="col-sm-12">
                                <input type="password" class="form-control" id="usrpwd" placeholder="Masukkan Password" name="password" required>
                            </div>
                            <label class="control-label col-sm-6" for="password">Konfirmasi Password</label>
                            <div class="col-sm-12">
                                <input type="password" class="form-control" id="usrpwd" placeholder="Masukkan Password" name="password1" required>
                            </div>
                        </div>
                        <div class="col-sm-offset-2 col-sm-12">
                            <div class="col-sm-12">
                                <input class="btn btn-primary" id="sbmt" type="submit" value="Daftar" name="daftar">
                                <a href="login.php" class="btn btn-info"> Kembali</a>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
</body>
</html>
