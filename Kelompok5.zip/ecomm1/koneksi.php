<?php
// buka koneksi ke database server
// sesuaikan dengan database sendiri
$hostname="localhost"; // sesuaikan
$username="root"; // sesuaikan
$password=""; //sesuaikan
$database="ecommerce1";
$koneksi=mysqli_connect("localhost","root","","ecommerce1") or die("Koneksi ke database Gagal");
if (!$connect=mysqli_connect($hostname,$username,$password))
{
echo mysqli_error($connect);
exit;
}
else
{
// select default database
mysqli_select_db($connect, $database);
}
?>
