<?php
    error_reporting(E_ALL ^ E_NOTICE);
    include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Input Produk</title>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
</head>
<body>
    <table align="center" width="1000" border="1">
        <tr>
            <td colspan="2" align="center"><h1>ecommerce</h1></td>
        </tr>
        <tr>
            <td width = "100">
            <ul>
		<li><a href="index.php" class="las la-igloo">Dashboard</a></li>
        <li><a href="kategori.php" class="las la-users">Kategori</a></li>
        <li><a href="produk.php" class="las la-book">Produk</a></li>
      <ul>

            </td>
            <td width="500">
                <form method="post" action="input_produk.php" >
                <table><br>

                <div class="form-group row">
                    <label class="control-label col-sm-2" for="kode">Kode Produk :</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="kode" placeholder="Masukkan Kode" name="kode">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="control-label col-sm-2" for="nama">Nama Produk :</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="nama" placeholder="Masukkan Nama" name="nama">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="control-label col-sm-2" for="stok">stok :</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="stok" placeholder="Masukkan stok" name="stok">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="control-label col-sm-2" for="harga">Harga:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="harga" placeholder="Masukkan harga" name="harga">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="control-label col-sm-2" for="input">Tanggal Input:</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" id="input" placeholder="Masukkan tanggal" name="input">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <button type="submit" name="submit" class="btn btn-primary"><i class="far fa-save"></i> Simpan</button>
                        <button type="reset" name="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i> Hapus</button>
                        <!--a href="logout.php" class="btn btn-dark"><i class="fas fa-sign-out-alt"></i> Logout</a-->
                    </div>
                </div><br><br>
                </table>
                </form>

                <?php
                    if (isset($_POST['submit'])){
                        $kode = $_POST['kode'];
                        $nama = $_POST['nama'];
                        $stok = $_POST['stok'];
                        $harga = $_POST['harga'];
                        $input = $_POST['input'];

                        $queryinsert = mysqli_query($connect, "INSERT INTO produk VALUES ('$kode', '$nama','$stok','$harga', '$input')");
                        echo mysqli_error($connect);

                        if ($queryinsert){
                ?>
                        <br>
                        <div class="alert alert-success alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success!</strong> Data produk Berhasil Diinput.
                        </div>
                <?php
                        }
                        else{
                ?>
                        <div class="alert alert-ddanger alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Failed!</strong> Data produk Gagal Diinput.
                        </div>
                <?php
                        }
                    }
                    
                ?>

            </td>
        </tr>
        <tr>
           
        </tr>
    </table>
</body>
</html>
