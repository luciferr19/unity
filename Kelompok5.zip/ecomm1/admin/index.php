<?php
session_start();
include "koneksi.php";
$cekuserlogin=$_SESSION['username'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Group 5</title>
<link href="../theme.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
if(empty($cekuserlogin)){
header("Location: login.php");
} else{ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1">
    <title>Admin Dash</title>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <link rel="stylesheet" href="index2.css">
</head>
<body>
    
    <input type="checkbox" id="nav-toggle">
    <div class="sidebar">
        <div class="sidebar-brand">
            <h2><span class="lab la-accusoft"></span> <span>Ecommerce </span></h2>
        </div>

        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="index.php" class="active"><span class="las la-igloo"></span>
                    <span>Dashboard</span></a>
                </li>

                <li>
                    <a href="kategori.php"><span class="las la-users"></span>
                    <span>Kategori</span></a>
                </li>

                <li>
                    <a href="produk.php"><span class="las la-book"></span>
                    <span>Produk</span></a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-content">
        <header>
            <h2>
                <label for="nav-toggle">
                    <span class="las la-bars"></span>
                </label>

                Dashboard
            </h2>

            <div class="search-wrapper">
                <span class="las la-search"></span>
                <input type="search" placeholder="Cari disini"/>
            </div>

            <div class="user-wrapper">
                <img src="images1.jpg" width="40px" height="40px" alt="">
                <div>
                    <h4>Five</h4>
                    <small>Super Admin</small>
                </div>
            </div>

            <div class="collapse navbar-collapse navbar-ex1-collapse"><ul class="nav navbar-nav navbar-right navbar-user">
            
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <?php=
$cekuserlogin=$_SESSION['username'];
?>
              <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php" onclick="return confirm('Apakah anda akan keluar?');"><i class="fa fa-power-off"></i> Keluar</a></li>
              </ul>
            </li>
          </ul>
        </div>

        </header>

        <main>

            <div class="dashboard-cards">
                <div class="card-single">
                    <div>
                        <h1>8</h1>
                        <span>Kategori</span>
                    </div>
                    <div>
                        <span class="las la-users"></span>
                    </div>
                </div>

                <div class="card-single">
                    <div>
                        <h1>10</h1>
                        <span>Produk</span>
                    </div>
                    <div>
                        <span class="las la-book"></span>
                    </div>
                </div>

                <div class="card-single">
                    <div>
                        <h1>1</h1>
                        <span>Checkout</span>
                    </div>
                    <div>
                        <span class="las la-reply"></span>
                    </div>
                </div>
            </div>

            <div class="recent-grid">
                <div class="projects">
                    <div class="card">
                        <div class="card-header">
                            <h3>Data Transaksi</h3>

                           
                        </div>
                        <div class="card-body">
                            <table width="100%">
                            <p style='color: #DD2F6E;'><b>Checkout </b> </p>
                                <thead>
                                    <tr>
                                  
                                        <th >ID </th>
                                        <th >no ktp </th>
                                        <th >nama </th>
                                        <th >notelp</th>
                                        <th >kodepos</th>
                                        <th >wkt checkout</th>
                                   
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $queryinfo = mysqli_query ($connect, "SELECT * FROM checkout WHERE checkout.idcheckout  = 1 ORDER BY idcheckout ");
                                    /*$no = 1;*/
                                    while ($checkout = mysqli_fetch_array($queryinfo)) {
                                ?>           
                                    <tr>
                                        <!--td></*?php echo $no?>*/</td-->
                                        <td><?=$checkout['idcheckout']?></td>
                                        <td><?=$checkout['noktp']?></td>
                                        <td><?=$checkout['nama']?></td>
                                        <td><?=$checkout['notelp']?></td>
                                        <td><?=$checkout['kodepos']?></td>
                                        <td><?=$checkout['wkt_checkout']?></td>
                                        
                                        <?php /*$no++;*/
                                    }
                                ?>

                                </tbody>
                                </table><br><br>

                                
                                    </tbody>
                                </table>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>
<?php } ?>
</body>
</html>