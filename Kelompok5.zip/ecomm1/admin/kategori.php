<?php
    error_reporting(E_ALL ^ E_NOTICE);
    include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce</title>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
</head>
<body>

  <table width="1000" border="1" align="center">
    <tr>
      <td colspan="2" align="center"><h1>Sistem Informasi Ecommerce</h1></td>
    </tr>
    <tr>
      <td width = "200">
      <ul>
		<li><a href="index.php" class="las la-igloo">Dashboard</a></li>
        <li><a href="kategori.php" class="las la-users">Kategori</a></li>
        <li><a href="produk.php" class="las la-book">Produk</a></li>
      <ul>
      </td>
      <td width="500">
        <a href="inputkategori.php"><i class="las la-file"></i>Input Kategori</a>
        <table class="table table-bordered">
        <thead> 
          <tr>
            <th>Kode Produk </th>
            <th>Kategori </th>
          
            
      </tr>
        </thead>

        <tbody>
          <?php
            $queryproduk = mysqli_query($connect, "SELECT * FROM kategori_produk order by idkategoriproduk");
            $jumproduk = mysqli_num_rows ($queryproduk);
            if ($jumproduk == 0){
          ?>       
            <tr>
              <td colspan="12" class="danger">Data Kategori Masih Kosong</td>
            </tr>
          <?php
            }
            else{
                while ($produk = mysqli_fetch_array($queryproduk))
            {
          ?>      
            <tr>
              <td><?=$produk['idkategoriproduk']?></td>
              <td><?=$produk['kategori']?></td>
             
              <td><a href="editkategori.php?idproduk=<?=$produk['idkategoriproduk']?>"><button type="button" class="btn btn-sm btn-info"><i class="las la-pen-fancy"></i> Edit</button></a> | <a href="kategori.php?hapus=ok&kd_buku=<?=$produk['idkategoriproduk']?>"><button type="button" class="btn btn-sm btn-danger"><i class="las la-trash-alt"></i> Hapus</button></a></td>
            </tr>
                                       
          <?php 
              }
            }
            if (isset($_GET['hapus'])){
              $idproduk = $_GET['idkategoriproduk'];
              $querydelete = mysqli_query($connect, "DELETE FROM kategori WHERE idkategoriproduk ='$idkategoriproduk'");
              if ($querydelete){
              ?>
                  <div class="alert alert-success alert-dismissable">
                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                      <strong>Success!</strong> Data Berhasil Dihapus.
                  </div>
              <?php
              }
              else{
              ?>
                  <div class="alert alert-ddanger alert-dismissable">
                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                      <strong>Failed!</strong> Data Gagal Dihapus.
                  </div>
              <?php
              }
            }
          ?>
          </tbody>
          </table>
</td>
</tr>
<tr>

</tr>
</table>
</body>
</html>