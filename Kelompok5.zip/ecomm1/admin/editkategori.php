<?php
    error_reporting(E_ALL ^ E_NOTICE);
    include "koneksi.php";
    $idkategoriproduk = $_GET['idkategoriproduk'];

    $queryinfo = mysqli_query($connect, "SELECT * FROM kategori_produk WHERE idkategoriproduk='$idkategoriproduk'");
    $info = mysqli_fetch_array($queryinfo);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori Ecommerce</title>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
</head>
<body>

<table align="center" width="1000" border="1">
        <tr>
            <td colspan="2" align="center"><h1>Edit Kategori Ecommerce</h1></td>
        </tr>
        <tr>
            <td width = "100">
            <ul>
		<li><a href="index.php" class="las la-igloo">Dashboard</a></li>
        <li><a href="kategori.php" class="las la-users">Kategori</a></li>
        <li><a href="produk.php" class="las la-book">Produk</a></li>
      <ul>
            </td>
            <td width="500">
                <form method="post" action="editkategori.php" >
                <table><br>

                <div class="form-group row">
                    <label class="control-label col-sm-2" for="kode">Kode Produk :</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="kode" placeholder="Masukkan Kode" name="kode">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="control-label col-sm-2" for="kategori">Kategori :</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="kategori" placeholder="Masukkan Kategori" name="kategori">
                    </div>
                </div>
                </div>
                
                <div class="form-group">
                    <div class="col-sm-12">
                        <button type="submit" name="edit" class="btn btn-sm btn-info"><i class="lar la-save"></i> Edit</button>
                        <button type="reset" name="reset" class="btn btn-danger"><i class="lar la-trash-alt"></i> Hapus</button>
                        <!--a href="logout.php" class="btn btn-dark"><i class="fas fa-sign-out-alt"></i> Logout</a-->
                    </div>
                </div><br><br>
                </table>
                </form>

                <?php
                    if (isset($_POST['edit'])){
                        $kode = $_POST['kode'];
                        $kategori = $_POST['kategori'];
                        

                        $queryedit = mysqli_query($connect, "UPDATE kategori_produk SET idkategoriproduk='$kode', kategori='$kategori' WHERE idkategoriproduk='$kode'");
                        echo mysqli_error($connect);

                        if ($queryedit){
                ?>
                            <div class="alert alert-success alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success!</strong> Data Berhasil Diedit. Klik <a href="kategori.php">disini</a> untuk Input Data Baru.
                             </div>
                        <?php
                        }
                        else{
                        ?>
                            <div class="alert alert-ddanger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Failed!</strong> Data Gagal Diedit.
                            </div>
                        <?php
                        }
                    }
                        ?>
        </tr>
        <tr>
            
        </tr>
    </table>
</body>
</html>