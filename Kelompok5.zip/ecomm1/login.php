<!DOCTYPE html>
<?php
include "koneksi.php";

    
    if (isset($_POST['login']))
    {
        $user=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['username'])));
    $pass=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_POST['password'])));
        $query = mysqli_query($connect, "SELECT * from login WHERE username='$user' and password='$pass'");
        $cek = mysqli_num_rows($query);
        if ($cek > 0)
        {
            setcookie("username", $user, time()+3600 );
            setcookie("password", $pass, time()+3600 );
            header("Location: index.php");
        }
        else
        {?><script>
            alert ("Username dan Password Tidak Tepat");</script><?php
        }
    }
?>
<meta charset="utf-8">
<html>
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Login | REENREN</title>
        <!--Menyisipkan Bootstrap-->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/style.css">
</head>
<style>
        body{
            background-image: url(bg1.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            background-attachment: fixed;
            height: 100%;
        }
        .title{
            text-align: center;
            font-size: 2.5em;
            color: #000;
        }
 
         
    </style>
       
        <div class="container">
            <center><h1 style="font-family: serif; padding-bottom: 60px; padding-top: 20px"></h1></center>
            <form method='post' action='login.php' autocomplete="off" class="form-login"><center><h2 style="font-family: serif;">LOGIN</h2></center>
                <div class="container">
                    <div class="col-12">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="user">Username</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" id="user" placeholder="Masukkan Username" name="username">
                            </div>
                            <label class="control-label col-sm-2" for="password">Password</label>
                            <div class="col-sm-12">
                                <input type="password" class="form-control" id="usrpwd" placeholder="Masukkan Password" name="password">
                            </div>
                        </div>
                        <div class="col-sm-offset-2 col-sm-12">
                            <div class="col-sm-12">
                                <button class="btn btn-primary" id="sbmt" type="submit" value="login" name="login"> Login</button>
                                <a href="daftar.php" class="btn btn-primary"> Daftar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
</body>
</html>
