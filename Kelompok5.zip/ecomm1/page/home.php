<?php
include "koneksi.php";
error_reporting (E_ALL ^ E_NOTICE);
$username = $_COOKIE['username'];
$password = $_COOKIE['password'];
    
    if (!isset($username))
    {
        ?>
        <script>
            alert('Cookie Habis');
            document.location='login.php';
        </script>
        <?php
        exit;
    }
?>
<section id="slideshow">
    <div class="slideshow">&nbsp;</div>
</section>
<section id="produk">
    <div class="container">
        <div class="produk-title">PRODUK TERBARU</div> 
        <div class="row">
            <?php
                $produktebaru=mysqli_query($koneksi,"SELECT * FROM produk ORDER BY idproduk ASC LIMIT 0,3");
                while($tampilproduk=mysqli_fetch_array($produktebaru)){
            ?>
            <div class="col-4">
                <div class="box-barang">
                    <img src="<?php echo $tampilproduk['gambar']; ?>">
                    <div class="barang-judul">
                        <a href="?page=detail_produk&&idproduk=<?php echo $tampilproduk['idproduk']; ?>">
                            <?php echo $tampilproduk['nama_produk']; ?>
                        </a>
                    </div>
                    <div class="barang-deskripsi"><?php echo $tampilproduk['deskripsi_singkat']; ?> ...</div>
                    <div class="barang-harga">Rp. <?php echo number_format($tampilproduk['harga'],2); ?></div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>
<section id="produk">
    <div class="container">
    	<div class="produk-title">PRODUK TERLARIS</div> 
	    <div class="row">
        <div class="col-4">
        			<div class="box-barang">
                        <img src="images/jack5.jpg">
                        <div class="barang-judul">Sweet Style</div>
                        <div class="barang-deskripsi"> bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.</div>
                        <div class="barang-harga">Rp. 1.000.000</div>
                    </div>
                    <div class="box-barang">
                        <img src="images/jack2.jpg">
                        <div class="barang-judul">Style 2 Jackson Wang Got7</div>
                        <div class="barang-deskripsi">bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.</div>
                        <div class="barang-harga">Rp. 12.000.000</div>
                    </div>
                    
         </div>
        <div class="col-8">
            <div class="row">
                <div class="col-6"><div class="box-barang">
                        <img src="images/hang1.jpg">
                        <div class="barang-judul">Style 1 Han So Hee</div>
                        <div class="barang-deskripsi">bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli</div>
                        <div class="barang-harga">Rp. 11.000.000</div>
                    </div></div>
                <div class="col-6"><div class="box-barang">
                        <img src="images/han2.jpg">
                        <div class="barang-judul">Style 2 Han So Hee</div>
                        <div class="barang-deskripsi">bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli</div>
                        <div class="barang-harga">Rp. 12.000.000</div>
                    </div></div>
            </div>
            <div class="row">
                <div class="col-3"><div class="box-barang">
                        <img src="images/jack3.jpg">
                        <div class="barang-judul">Style 3 Jackson Wang Got7</div>
                        <div class="barang-deskripsi">bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli</div>
                        <div class="barang-harga">Rp. 13.000.000</div>
                    </div></div>
                <div class="col-3"><div class="box-barang">
                        <img src="images/jack4.jpg">
                        <div class="barang-judul">Style 4 Jackson Wang Got7</div>
                        <div class="barang-deskripsi">bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli</div>
                        <div class="barang-harga">Rp. 14.000.000</div>
                    </div></div>
                <div class="col-3"><div class="box-barang">
                        <img src="images/han3.jpg">
                        <div class="barang-judul">Style 3 Han So Hee</div>
                        <div class="barang-deskripsi">bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli</div>
                        <div class="barang-harga">Rp. 13.000.000</div>
                    </div></div>
                <div class="col-3"><div class="box-barang">
                        <img src="images/han4.jpg">
                        <div class="barang-judul">Style 4 Han So Hee</div>
                        <div class="barang-deskripsi">bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli</div>
                        <div class="barang-harga">Rp. 14.000.000</div>
                    </div></div>
            </div>
        </div>
    </div>
    </div>
</section>