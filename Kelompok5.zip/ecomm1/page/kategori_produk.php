<?php
include "koneksi.php";
error_reporting (E_ALL ^ E_NOTICE);
$username = $_COOKIE['username'];
$password = $_COOKIE['password'];
    
    if (!isset($username))
    {
        ?>
        <script>
            alert('Cookie Habis');
            document.location='login.php';
        </script>
        <?php
        exit;
    }
?>
<?php
   $idkategoriproduk=mysqli_real_escape_string($koneksi, trim(strip_tags(@$_GET['idkategoriproduk'])));
    if(!empty($idkategoriproduk)){
        $proc_query="WHERE idkategoriproduk='$idkategoriproduk'";
    }else{
        $proc_query="";
    }
    $kategori=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM kategori_produk $proc_query"));
?>
<div class="container">
	<h3>KATEGORI PRODUK <?php if(!empty($idkategoriproduk)){ ?><font color="red"><?php echo strtoupper($kategori['kategori']); ?></font> <?php } ?></h3>
   
   
   <div class="row">
   	<div class="col-9">
    	
        <?php
                $produktebaru=mysqli_query($koneksi,"SELECT * FROM produk $proc_query ORDER BY idproduk DESC LIMIT 0,3");
                $cekjmlproduk=mysqli_num_rows($produktebaru);
                if($cekjmlproduk==0){
                    echo "<h3>Maaf!! Produk pada Kategori $kategori[kategori] Tidak ada.</h3>";
                }
                while($tampilproduk=mysqli_fetch_array($produktebaru)){
            ?>
            <div class="col-4">
                <div class="box-barang">
                    <img src="<?php echo $tampilproduk['gambar']; ?>">
                    <div class="barang-judul">
                        <a href="?page=detail_produk&&idproduk=<?php echo $tampilproduk['idproduk']; ?>">
                            <?php echo $tampilproduk['nama_produk']; ?>
                        </a>
                    </div>
                    <div class="barang-deskripsi"><?php echo $tampilproduk['deskripsi_singkat']; ?> ...</div>
                    <div class="barang-harga">Rp. <?php echo number_format($tampilproduk['harga'],2); ?></div>
                </div>
            </div>
            <?php } ?>


    </div>
    <div class="col-3">
    	KATEGORI PRODUK
        <ul>
        	<?php
			$kategori=mysqli_query($koneksi,"SELECT * FROM kategori_produk");
			while($kategori_tampil=mysqli_fetch_array($kategori)){
			?>
        		<li><a href="?page=kategori_produk&&idkategoriproduk=<?php echo $kategori_tampil['idkategoriproduk']?>"><?php echo $kategori_tampil['kategori']; ?></a></li>
        	<?php } ?>
        </ul>
    </div>
   </div>
    
    
 </div>