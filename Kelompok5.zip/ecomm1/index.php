<?php
include "koneksi.php";
error_reporting (E_ALL ^ E_NOTICE);
$username = $_COOKIE['username'];
$password = $_COOKIE['password'];
  
  if (!isset($username))
  {
    ?>
    <script>
      alert('Cookie Habis');
      document.location='login.php';
    </script>
    <?php
    exit;
  }
?>
<head>
<meta charset="utf-8">
<title>Group 5</title>
<link href="theme.css" type="text/css" rel="stylesheet">
</head>

<body>
<section id="header">
	<div class="menu-atas">&nbsp;</div>
    <div class="header">
    	<div class="container">
            <div class="row">
                <div class="col-4">
                    REENREN.COM
                </div>
                <div class="col-8">
                    <a href="?" class="menu-style">Beranda</a>
                    <a href="?page=kategori_produk" class="menu-style">Kategori Produk</a>
                    <a href="?page=keranjang_belanja" class="menu-style">Keranjang Belanja</a>
                    <a href="?page=checkout" class="menu-style">Checkout</a>
                    <a href="logout.php" class="menu-style">Logout</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
	$page=@$_GET['page'];
	if($page=="home"){
		include "page/home.php";

    }elseif($page=="detail_produk"){
        include "page/detail_produk.php";

	}elseif($page=="kategori_produk"){
		include "page/kategori_produk.php";

	}elseif($page=="daftar_pembelian"){
		include "page/daftar_pembelian.php";

	}elseif($page=="checkout"){
		include "page/checkout.php";

    }elseif($page=="proses_order"){
        include "page/proses_order.php";

    }elseif($page=="keranjang_belanja"){
        include "page/keranjang_belanja.php";

    }elseif($page=="order_finish"){
        include "page/order_finish.php";
	
    }else{
		include "page/home.php";
	}
?>
<section id="footer">
	<div class="footer1">
    	<div class="container">
            <div class="row">
                <div class="col-4 kolom-footer">
                <h4>Navigation</h4>
                        <ul class="nav">
                            <li><a href="./index.php">Homepage</a></li>
                            <li><a href="./register.php">Login</a></li>                         
                        </ul>   
                </div>
                <div class="col-4 kolom-footer">
                <h4>Follow Us</h4>
                        <ul class="nav">
                            <li><a href="https://www.instagram.com/"><img src="ig.jfif" width="40" height="35"></a></li>
                        </ul>
                </div>
                <div class="col-4 kolom-footer">
                <p>Thank you for visiting our website, we hope our website can meet your needs and desires, your satisfaction is our success. the goods we sell are high quality goods and guaranteed safe delivery to your hands. happy shopping and hope you are satisfied with our service</p>
                </div>
            </div>
        </div>
    </div>
    <div class="footer2">Create by Group 5 &copy; 2021. All Right Reserved</div>
</section>
</body>
</html>