-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2021 at 09:13 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `idadmin` int(11) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(35) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`idadmin`, `username`, `password`, `nama`) VALUES
(1, 'reny', 'erna', 'malioy'),
(5, 'kelompok', 'lima', 'kelompok Lima');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `idcheckout` int(11) NOT NULL,
  `noktp` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `notelp` varchar(15) NOT NULL,
  `kodepos` varchar(10) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `alamat_pengiriman` varchar(255) NOT NULL,
  `jenis_pengiriman` varchar(35) NOT NULL,
  `tgl_checkout` date NOT NULL,
  `wkt_checkout` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`idcheckout`, `noktp`, `nama`, `notelp`, `kodepos`, `alamat`, `alamat_pengiriman`, `jenis_pengiriman`, `tgl_checkout`, `wkt_checkout`) VALUES
(1, '012345', 'Reny Erna Malioy', '081236654886', '12345', 'makassar', 'Makassar', 'JNE', '2021-05-23', '11:35:20'),
(2, '012345', 'RENITAA', '081236654886', '12345', 'Manunggal 22 no 08', 'Makassar', 'JNT', '2021-05-23', '13:08:09'),
(3, '12345', 'Renreen', '081236654886', '12345', 'Jln Manunggal 22', 'Makassar', 'JNT', '2021-05-23', '13:19:55'),
(4, '012345', 'Reny Erna Malioy', '081236654886', '12345', 'jln manunggal 22', 'Makassar', 'JNT', '2021-05-23', '19:49:55'),
(5, '012345', 'Reny Erna Malioy', '081236654886', '12345', 'jln manunggal 22', 'Makassar', 'JNE', '2021-05-24', '11:06:21'),
(6, '12345', 'leady', '081236654886', '12345', 'Toraja', 'Makassar wkwk jauhnya', 'JNE', '2021-05-24', '11:12:35'),
(7, '012345', 'Reny Erna', '081236654886', '12345', 'jln manunggal', 'makassar', 'JNT', '2021-05-27', '09:50:36'),
(8, '12345', 'ochi wonata', '0812456792', '12345', 'jln manunggal', 'makassar', 'JNE', '2021-06-01', '18:55:52');

-- --------------------------------------------------------

--
-- Table structure for table `kategori_produk`
--

CREATE TABLE `kategori_produk` (
  `idkategoriproduk` int(11) NOT NULL,
  `kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori_produk`
--

INSERT INTO `kategori_produk` (`idkategoriproduk`, `kategori`) VALUES
(1, 'Pakaian Pria Dewasa'),
(2, 'Pakaian Wanita Dewasa'),
(3, 'Gaun'),
(4, 'Pakaian Anak Anak Pria'),
(5, 'Pakaian Anak Anak Wanita'),
(6, 'Rompi');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'renyerna', 'malioy'),
(13, 'bumi', 'datar');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `idmember` int(11) NOT NULL,
  `namamember` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nohp` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pesan_produk`
--

CREATE TABLE `pesan_produk` (
  `idpesanproduk` int(11) NOT NULL,
  `idproduk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `idproduk` int(11) NOT NULL,
  `idkategoriproduk` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `stok` decimal(10,2) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `deskripsi_singkat` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `tanggal_input` date NOT NULL,
  `waktu_input` time NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`idproduk`, `idkategoriproduk`, `nama_produk`, `stok`, `harga`, `deskripsi_singkat`, `deskripsi`, `tanggal_input`, `waktu_input`, `gambar`) VALUES
(2, 1, 'Style 2 Jackson Wang Got7', '12.00', '12000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-02', '13:16:32', 'images/jack2.jpg'),
(3, 1, 'Style 3 Jackson Wang Got7', '13.00', '13000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-03', '17:31:21', 'images/jack3.jpg'),
(4, 1, 'Style 4 Jackson Wang Got7', '14.00', '14000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-04', '15:28:55', 'images/jack4.jpg'),
(5, 1, 'Style 5 Jackson Wang Got7', '15.00', '15000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-05', '15:28:55', 'images/jack5.jpg'),
(6, 2, 'Style 1 Han So Hee', '11.00', '11000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-06', '16:28:55', 'images/han1.jpg'),
(7, 2, 'Style 2 Han Soo Hee', '12.00', '12000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-07', '17:31:21', 'images/han2.jpg'),
(8, 2, 'Style 3 Han So Hee', '13.00', '13000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-08', '13:16:32', 'images/han3.jpg'),
(9, 2, 'Style 4 Han So Hee', '14.00', '14000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-09', '17:31:21', 'images/han4.jpg'),
(10, 2, 'Style 5 Han So Hee', '11.00', '15000000.00', 'bahan yang nyaman, ringan, tidak mudah rusak serta menyerap keringat juga biasanya menjadi pilihan banyak pembeli.', '– 100% Merino Wool, bahan eksklusif yang halus dan terasa nyaman di kulit. Bahannya yang licin juga membuat baju tidak mudah terkena noda membandel.\r\n– Pas dan terlihat keren untuk Anda yang berukuran umum.\r\n– Unlined Sweater terasa ringan di badan dan terasa adem digunakan.', '2021-05-10', '17:31:21', 'images/han5.jpg'),
(12, 3, 'Style Gaun 1 ', '12.00', '5000000.00', 'nyaman', 'nyaman dan elegan', '2021-06-09', '19:32:34', 'images/hang2.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idadmin`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`idcheckout`);

--
-- Indexes for table `kategori_produk`
--
ALTER TABLE `kategori_produk`
  ADD PRIMARY KEY (`idkategoriproduk`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`idmember`);

--
-- Indexes for table `pesan_produk`
--
ALTER TABLE `pesan_produk`
  ADD PRIMARY KEY (`idpesanproduk`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`idproduk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `idadmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `idcheckout` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `kategori_produk`
--
ALTER TABLE `kategori_produk`
  MODIFY `idkategoriproduk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `idmember` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pesan_produk`
--
ALTER TABLE `pesan_produk`
  MODIFY `idpesanproduk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `idproduk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
